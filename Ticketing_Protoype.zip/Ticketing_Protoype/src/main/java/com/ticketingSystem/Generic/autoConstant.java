package com.ticketingSystem.Generic;

public interface autoConstant {
		
		public final String datafile="./appData.properties";
		public final String currentDir = System.getProperty("user.dir");
		public final String photo="\\Photo\\";	 
		public final String reportPath="\\ExtentReport\\";
		public final String repoPath="\\ExtentReport\\";
//		public final String repoPath="\\ExtentRep\\";	
		public String excelPath = "\\new.xlsx";
		//public String excelPath = "\\LABOUR_CHARGES_RATE_MASTER-NASHIK_BRANCH.xlsx";

}
