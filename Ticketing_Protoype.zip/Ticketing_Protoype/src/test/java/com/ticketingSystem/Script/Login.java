package com.ticketingSystem.Script;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.ticketingSystem.Generic.BaseClass;

public class Login extends BaseClass {
	
	@Test
	public void test01() throws FileNotFoundException, IOException, Exception
	{
		System.out.println(timestamp);
		callURL(p.toReadDataFromPropertyFile("URL"));
		Thread.sleep(3000);
		
		createTest("Amreen", "");

		XSSFWorkbook wb = new XSSFWorkbook(currentDir+excelPath); 
		XSSFSheet sh = wb.getSheetAt(0);

		int noOfRows = sh.getPhysicalNumberOfRows();

		System.out.println(noOfRows);
		for (int i = 1; i < noOfRows+1; i++) {
	
		String uname = p.toReadDataFromExcel(0, i, 0);
		String pwd = p.toReadDataFromExcel(0, i, 1);
		

		ll.loginPage(driver, uname, pwd);
//		try {
//			onTestFailure("Failed cases");
//			
//			String msg = driver.findElement(By.xpath("//div[text()='Username does not match !!!']")).getText();
//			System.out.println("Uname : " +uname+ " Password : "+pwd+ " : "+msg);
		
//			onTestFailure("Uname : " +uname+ " Password : "+pwd+ " : "+msg);
//		} catch (Exception e) {
//			onTestSuccess("Uname : " +uname+ " Password : "+pwd);
//			System.out.println("Logged in successfully");
//			onTestSuccess("Logged in successfully");
//		}
		
System.out.println("Abhijeet..");
System.out.println(noOfRows);

	
		Thread.sleep(3000); 
	}

	}
	
}
